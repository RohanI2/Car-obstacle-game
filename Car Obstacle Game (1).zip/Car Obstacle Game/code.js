var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["089d6f20-7ca9-4faf-8135-9fed0805ee96","e7cfe349-05c8-43c5-8c89-2b91e8362534","447b9fa8-c5a4-4be4-a259-ad1aee54ce48","55ac7fbd-bfd7-460a-8f9d-377ce75a73b4"],"propsByKey":{"089d6f20-7ca9-4faf-8135-9fed0805ee96":{"name":"black","sourceUrl":"assets/api/v1/animation-library/gamelab/CSqSIJEb65ONvhatlX8ENonwX._VZQ_n/category_vehicles/car_black.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"CSqSIJEb65ONvhatlX8ENonwX._VZQ_n","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/CSqSIJEb65ONvhatlX8ENonwX._VZQ_n/category_vehicles/car_black.png"},"e7cfe349-05c8-43c5-8c89-2b91e8362534":{"name":"orange","sourceUrl":"assets/api/v1/animation-library/gamelab/PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu/category_vehicles/car_red.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu/category_vehicles/car_red.png"},"447b9fa8-c5a4-4be4-a259-ad1aee54ce48":{"name":"blue","sourceUrl":"assets/api/v1/animation-library/gamelab/lHG1XFlqFup4wzdHby85uHkMnnYotG1g/category_vehicles/car_blue.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"lHG1XFlqFup4wzdHby85uHkMnnYotG1g","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/lHG1XFlqFup4wzdHby85uHkMnnYotG1g/category_vehicles/car_blue.png"},"55ac7fbd-bfd7-460a-8f9d-377ce75a73b4":{"name":"green","sourceUrl":null,"frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"XwDmyppVvy6yI82FgVS.ixByw3n7_58.","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/55ac7fbd-bfd7-460a-8f9d-377ce75a73b4.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var car1, car2, car3,car4;
var boundary1, boundary2;
var player;


  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  player = createSprite(20,190,13,13);
  player.shapeColor = "green";
  
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car4 = createSprite(270,250,10,10);
  car4.shapeColor = "red";
 
 
   
 
//add the velocity to make the car move.
car1.velocityY=10;
car2.velocityY=10;
car3.velocityY=10;
car4.velocityY=10;
function draw() {
  createEdgeSprites();
   background("white");
  text("Lives: " + life,180,100);
  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  fill("yellow");
  rect(345,120,52,140);
  /*if (car1.isTouching(boundary1)){
   car1.mirrorY(-1);
 }
 if (car2.isTouching(boundary1)){
   car2.mirrorY(-1);
 }
 if (car3.isTouching(boundary1)){
   car3.mirrorY(-1);
 }
 if (car4.isTouching(boundary1)){
   car4.mirrorY(-1);
 }
if (car1.isTouching(boundary2)){
   car1.mirrorY(-1);
 }
 if (car2.isTouching(boundary2)){
   car2.mirrorY(-1);
 }
 if (car3.isTouching(boundary2)){
   car3.mirrorY(-1);
 }
 if (car4.isTouching(boundary2)){
   car4.mirrorY(-1);
 }
*/
 
// create bounceoff function to make the car bounceoff the boundaries
car1.bounceOff(boundary1);
car1.bounceOff(boundary2);
car2.bounceOff(boundary1);
car2.bounceOff(boundary2);
car3.bounceOff(boundary1);
car3.bounceOff(boundary2);
car4.bounceOff(boundary1);
car4.bounceOff(boundary2);
//Animations
car1.setAnimation("black");
car2.setAnimation("orange");
car3.setAnimation("blue");
car4.setAnimation("green");
//Scaling the animations
car1.scale=0.2;
car2.scale=0.2;
car3.scale=0.2;
car4.scale=0.2;
//Add the condition to make the sam move left and right
 if (keyDown("right")){
   player.x=player.x+5;
 }
 if (keyDown("left")){
   player.x=player.x-5;
 }
 if (keyDown("up")){
   player.y=player.y-5;
 }
 if (keyDown("down")){
   player.y=player.y+5;
 }
//Add the condition to reduce the life of sam if it touches the car.
player.bounceOff(edges);
player.bounceOff(boundary1);
player.bounceOff(boundary2);
if (life===5){
  textSize(40);
  textFont("black");
  text("You lose",140,325);
}
 if (player.isTouching(car1)) {
   life=life+1;
   player.x=20;
   player.y=190;
 }
  if (player.isTouching(car2)) {
   life=life+1;
   player.x=20;
   player.y=190;
 }
 if (player.isTouching(car3)) {
   life=life+1;
   player.x=20;
   player.y=190;
 } if (player.isTouching(car4)) {
   life=life+1;
   player.x=20;
   player.y=190;
 }
 if (player.x>345){
   textSize(40);
   textFont("black");
   text("You win!",140,325);
 }
 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
